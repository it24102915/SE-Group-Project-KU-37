package com.example.Payments;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentsApplicationTest {

    @Test
    void contextLoads() {
    }

}
