package com.example.Payments.dto;

    public class PaymentDTO {
        private Integer orderId;
        private String paymentMethod;
        private Double amount;
        private String transactionId;

        public PaymentDTO() {}

        public PaymentDTO(Integer orderId, String paymentMethod, Double amount, String transactionId) {
            this.orderId = orderId;
            this.paymentMethod = paymentMethod;
            this.amount = amount;
            this.transactionId = transactionId;
        }

        // Getters & setters
        public Integer getOrderId() { return orderId; }
        public void setOrderId(Integer orderId) { this.orderId = orderId; }

        public String getPaymentMethod() { return paymentMethod; }
        public void setPaymentMethod(String paymentMethod) { this.paymentMethod = paymentMethod; }

        public Double getAmount() { return amount; }
        public void setAmount(Double amount) { this.amount = amount; }

        public String getTransactionId() { return transactionId; }
        public void setTransactionId(String transactionId) { this.transactionId = transactionId; }
    }


