package com.example.Payments.payments;

import com.example.Payments.dto.PaymentDTO;
import com.example.Payments.model.Payment;
import org.springframework.stereotype.Component;

@Component
public class CardPaymentStrategy implements PaymentStrategy {

    @Override
    public Payment processPayment(PaymentDTO dto, Payment payment) throws Exception {
        // Example: build card payload, call gateway SDK / REST endpoint
        // For this lab, we'll simulate the gateway response:
        String fakeGatewayResp = "CARD_GATEWAY: approved txnId=" + dto.getTransactionId();
        payment.setGatewayResponse(fakeGatewayResp);
        payment.setPaymentDetails("Card processed (masked)");
        payment.setStatus("completed"); // or pending if 3DS required
        return payment;
    }

    @Override
    public String getName() {
        return "CARD";
    }
}
