package com.example.Payments.payments;

import org.springframework.stereotype.Component;
import jakarta.annotation.PostConstruct;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
public class PaymentStrategyFactory {

    private final List<PaymentStrategy> strategies;
    private Map<String, PaymentStrategy> map;

    public PaymentStrategyFactory(List<PaymentStrategy> strategies) {
        this.strategies = strategies;
    }

    @PostConstruct
    private void init() {
        map = strategies.stream()
                .collect(Collectors.toMap(s -> s.getName().toUpperCase(), s -> s));
    }

    public PaymentStrategy getStrategy(String method) {
        if (method == null) return null;
        return map.get(method.toUpperCase());
    }
}

