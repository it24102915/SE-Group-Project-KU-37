package com.example.Payments.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ViewController {

    @GetMapping("/dashboard")
    public String dashboard(HttpSession session) {
        if(session.getAttribute("username") == null) {
            return "redirect:/login.html"; // not logged in
        }
        return "dashboard.html"; // user is logged in
    }

    @GetMapping("/login")
    public String login() {
        return "login.html";
    }
}