package com.example.Payments.service;

import com.example.Payments.dto.PaymentDTO;
import com.example.Payments.model.Payment;
import com.example.Payments.payments.PaymentStrategy;
import com.example.Payments.payments.PaymentStrategyFactory;
import com.example.Payments.repo.PaymentRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class PaymentService {

    private final PaymentRepository repo;
    private final PaymentStrategyFactory factory;

    public PaymentService(PaymentRepository repo, PaymentStrategyFactory factory) {
        this.repo = repo;
        this.factory = factory;
    }

    public Payment process(PaymentDTO dto) {
        // create payment entity (pre-populate common fields)
        Payment payment = new Payment();
        payment.setOrderId(dto.getOrderId());
        payment.setPaymentMethod(dto.getPaymentMethod());
        payment.setAmount(dto.getAmount());
        payment.setTransactionId(dto.getTransactionId());
        payment.setPaymentDate(LocalDateTime.now());
        payment.setStatus("initiated"); // default

        // choose strategy
        PaymentStrategy strategy = factory.getStrategy(dto.getPaymentMethod());
        try {
            if (strategy != null) {
                payment = strategy.processPayment(dto, payment);
            } else {
                // fallback: unknown method -> set failed or pending
                payment.setStatus("failed");
                payment.setGatewayResponse("No strategy for: " + dto.getPaymentMethod());
            }
        } catch (Exception ex) {
            payment.setStatus("failed");
            payment.setGatewayResponse("Exception: " + ex.getMessage());
        }

        // persist result
        return repo.save(payment);
    }
}

