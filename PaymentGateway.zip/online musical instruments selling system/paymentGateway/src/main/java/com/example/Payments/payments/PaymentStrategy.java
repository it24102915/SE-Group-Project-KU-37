package com.example.Payments.payments;

import com.example.Payments.dto.PaymentDTO;
import com.example.Payments.model.Payment;

// Strategy interface: all payment methods implement this
public interface PaymentStrategy {
    /**
     * Process the payment request and return an updated Payment entity.
     * Implementations may call external gateways, set gateway response,
     * set status ("pending","completed","failed") and other details.
     */
    Payment processPayment(PaymentDTO dto, Payment payment) throws Exception;

    /**
     * A short string identifier for this strategy (e.g., "CARD", "PAYPAL", "COD")
     * This can be used by the factory to map incoming paymentMethod values.
     */
    String getName();
}

