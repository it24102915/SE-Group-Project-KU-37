package com.example.Payments.payments;

import com.example.Payments.dto.PaymentDTO;
import com.example.Payments.model.Payment;
import org.springframework.stereotype.Component;

@Component
public class CashOnDeliveryStrategy implements PaymentStrategy {

    @Override
    public Payment processPayment(PaymentDTO dto, Payment payment) throws Exception {
        // COD: set payment as pending until delivery collected
        payment.setGatewayResponse("COD: no gateway");
        payment.setPaymentDetails("Collect on delivery");
        payment.setStatus("pending");
        return payment;
    }

    @Override
    public String getName() {
        return "COD";
    }
}
