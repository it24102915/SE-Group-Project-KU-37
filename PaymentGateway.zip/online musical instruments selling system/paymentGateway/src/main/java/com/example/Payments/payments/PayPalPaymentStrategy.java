package com.example.Payments.payments;

import com.example.Payments.dto.PaymentDTO;
import com.example.Payments.model.Payment;
import org.springframework.stereotype.Component;

@Component
public class PayPalPaymentStrategy implements PaymentStrategy {

    @Override
    public Payment processPayment(PaymentDTO dto, Payment payment) throws Exception {
        // Simulate PayPal flow:
        String fakeGatewayResp = "PAYPAL_GATEWAY: approved id=" + dto.getTransactionId();
        payment.setGatewayResponse(fakeGatewayResp);
        payment.setPaymentDetails("PayPal payment token");
        payment.setStatus("completed");
        return payment;
    }

    @Override
    public String getName() {
        return "PAYPAL";
    }
}

