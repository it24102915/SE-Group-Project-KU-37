package com.example.Payments.controller;

import com.example.Payments.model.User;
import com.example.Payments.repo.UserRepository;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/auth")
public class AuthController {

    private final UserRepository userRepo;

    public AuthController(UserRepository userRepo) {
        this.userRepo = userRepo;
    }

    // LOGIN
    @PostMapping("/login")
    public String login(@RequestParam String username, @RequestParam String password) {
        Optional<User> userOpt = userRepo.findByUsername(username);

        if (userOpt.isPresent()) {
            User user = userOpt.get();
            if (user.getPassword().equals(password)) {
                return "✅ Login successful";
            }
        }
        return "❌ Invalid credentials";
    }

    // SIGNUP
    @PostMapping("/signup")
    public String signup(@RequestParam String username,
                         @RequestParam String password) {
        Optional<User> existingUser = userRepo.findByUsername(username);

        if (existingUser.isPresent()) {
            return "⚠️ Username already exists";
        }

        User user = new User();
        user.setUsername(username);
        user.setPassword(password); // ⚠️ Plain text for now (replace with BCrypt later)
        userRepo.save(user);

        return "✅ Signup successful";
    }
}
