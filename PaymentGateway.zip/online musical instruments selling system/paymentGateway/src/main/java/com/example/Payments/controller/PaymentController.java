package com.example.Payments.controller;

import com.example.Payments.dto.PaymentDTO;
import com.example.Payments.model.Payment;
import com.example.Payments.repo.PaymentRepository;
import com.example.Payments.service.PaymentService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * PaymentController
 * Acts as the entry point for payment-related REST operations.
 * Delegates payment processing logic to PaymentService (Strategy Pattern context).
 */
@RestController
@RequestMapping("/Payments")
public class PaymentController {

    private final PaymentRepository repo;
    private final PaymentService paymentService;

    // Constructor injection (Spring automatically wires dependencies)
    public PaymentController(PaymentRepository repo, PaymentService paymentService) {
        this.repo = repo;
        this.paymentService = paymentService;
    }

    // CREATE - now uses Strategy Pattern via PaymentService
    @PostMapping
    public Payment create(@RequestBody PaymentDTO dto) {
        // Delegate payment processing to context (PaymentService)
        return paymentService.process(dto);
    }

    // READ all payments
    @GetMapping
    public List<Payment> getAllPayments() {
        return repo.findAll();
    }

    // READ by ID
    @GetMapping("/{id}")
    public Payment getOne(@PathVariable Integer id) {
        return repo.findById(id).orElse(null);
    }

    // UPDATE payment (optional – could be handled by strategy too)
    @PutMapping("/{id}")
    public Payment update(@PathVariable Integer id, @RequestBody PaymentDTO dto) {
        return repo.findById(id).map(p -> {
            p.setOrderId(dto.getOrderId());
            p.setPaymentMethod(dto.getPaymentMethod());
            p.setAmount(dto.getAmount());
            p.setTransactionId(dto.getTransactionId());
            return repo.save(p);
        }).orElse(null);
    }

    // DELETE a payment by ID
    @DeleteMapping("/{id}")
    public String delete(@PathVariable Integer id) {
        repo.deleteById(id);
        return "Deleted payment with ID: " + id;
    }

    // VERIFY payment transaction
    @PostMapping("/verify/{transactionId}")
    public Payment verify(@PathVariable String transactionId) {
        Payment p = repo.findByTransactionId(transactionId);
        if (p != null) {
            p.setStatus("completed");
            return repo.save(p);
        }
        return null;
    }
}
