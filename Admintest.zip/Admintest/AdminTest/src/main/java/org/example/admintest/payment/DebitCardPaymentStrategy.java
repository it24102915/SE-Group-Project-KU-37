package org.example.admintest.payment;

import org.example.admintest.Payment;
import org.springframework.stereotype.Component;

@Component("debit_card")
public class DebitCardPaymentStrategy implements PaymentStrategy {
    @Override
    public PaymentResult process(Payment payment) {
        String txn = "DEBIT-" + System.currentTimeMillis();
        String gw = "Debit gateway simulated: txn=" + txn;
        return PaymentResult.success("Debit card processed", gw, txn);
    }
}
