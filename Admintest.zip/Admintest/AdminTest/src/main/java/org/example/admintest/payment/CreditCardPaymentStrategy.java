package org.example.admintest.payment;

import org.example.admintest.Payment;
import org.springframework.stereotype.Component;

@Component("credit_card")
public class CreditCardPaymentStrategy implements PaymentStrategy {
    @Override
    public PaymentResult process(Payment payment) {
        String txn = "CARD-" + System.currentTimeMillis();
        String gw = "Card gateway simulated: approved txn=" + txn;
        return PaymentResult.success("Card charged", gw, txn);
    }
}
