package org.example.admintest.products;

import jakarta.servlet.http.HttpSession;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/admin/products")
public class ProductController {

    private final ProductFunctions dao;

    public ProductController(ProductFunctions dao) {
        this.dao = dao;
    }

    @GetMapping
    public String productsPage(HttpSession session) {
        if (!Boolean.TRUE.equals(session.getAttribute("isAdminLoggedIn"))) {
            return "redirect:/admin";
        }
        return "adminproducts";
    }

    @GetMapping("/pending")
    @ResponseBody
    public List<Product> pending(HttpSession session) {
        if (!Boolean.TRUE.equals(session.getAttribute("isAdminLoggedIn"))) return List.of();
        return dao.findByStatus("pending");
    }

    @GetMapping("/pending/count")
    @ResponseBody
    public Map<String,Object> pendingCount(HttpSession session) {
        if (!Boolean.TRUE.equals(session.getAttribute("isAdminLoggedIn"))) return Map.of("count", 0);
        int c = dao.countByStatus("pending");
        return Map.of("count", c);
    }

    @GetMapping("/discontinued")
    @ResponseBody
    public List<Product> discontinued(HttpSession session) {
        if (!Boolean.TRUE.equals(session.getAttribute("isAdminLoggedIn"))) return List.of();
        return dao.findDiscontinued();
    }

    @GetMapping("/discontinued/count")
    @ResponseBody
    public Map<String,Object> discontinuedCount(HttpSession session) {
        if (!Boolean.TRUE.equals(session.getAttribute("isAdminLoggedIn"))) return Map.of("count", 0);
        int c = dao.countDiscontinued();
        return Map.of("count", c);
    }

    @GetMapping("/{id}")
    @ResponseBody
    public ResponseEntity<?> get(@PathVariable int id, HttpSession session) {
        if (!Boolean.TRUE.equals(session.getAttribute("isAdminLoggedIn"))) {
            return ResponseEntity.status(401).body(Map.of("ok", false, "msg", "Not authorized"));
        }
        Product p = dao.findById(id);
        if (p == null) return ResponseEntity.status(404).body(Map.of("ok", false, "msg", "Product not found"));
        return ResponseEntity.ok(p);
    }

    @PostMapping("/{id}/approve")
    @ResponseBody
    public ResponseEntity<?> approve(@PathVariable int id, HttpSession session) {
        if (!Boolean.TRUE.equals(session.getAttribute("isAdminLoggedIn"))) {
            return ResponseEntity.status(401).body(Map.of("ok", false, "msg", "Not authorized"));
        }
        Object adminObj = session.getAttribute("adminUserId");
        int adminId = 0;
        if (adminObj instanceof Number) adminId = ((Number) adminObj).intValue();

        int rows = dao.approve(id, adminId);
        if (rows > 0) return ResponseEntity.ok(Map.of("ok", true));
        return ResponseEntity.badRequest().body(Map.of("ok", false, "msg", "Could not approve (maybe status not pending)"));
    }

    @PostMapping("/{id}/reject")
    @ResponseBody
    public ResponseEntity<?> reject(@PathVariable int id, @RequestBody Map<String,String> body, HttpSession session) {
        if (!Boolean.TRUE.equals(session.getAttribute("isAdminLoggedIn"))) {
            return ResponseEntity.status(401).body(Map.of("ok", false, "msg", "Not authorized"));
        }
        Object adminObj = session.getAttribute("adminUserId");
        int adminId = 0;
        if (adminObj instanceof Number) adminId = ((Number) adminObj).intValue();

        String reason = body.getOrDefault("reason","");
        int rows = dao.reject(id, adminId, reason);
        if (rows > 0) return ResponseEntity.ok(Map.of("ok", true));
        return ResponseEntity.badRequest().body(Map.of("ok", false, "msg", "Could not reject (maybe status not pending)"));
    }

    @PostMapping("/{id}/stock-adjust")
    @ResponseBody
    public ResponseEntity<?> adjustStock(@PathVariable int id, @RequestBody Map<String,Object> body, HttpSession session) {
        if (!Boolean.TRUE.equals(session.getAttribute("isAdminLoggedIn"))) {
            return ResponseEntity.status(401).body(Map.of("ok", false, "msg", "Not authorized"));
        }
        Object adminObj = session.getAttribute("adminUserId");
        int adminId = 0;
        if (adminObj instanceof Number) adminId = ((Number) adminObj).intValue();

        Integer qtyChange = body.get("qtyChange") instanceof Number ? ((Number)body.get("qtyChange")).intValue() : null;
        String changeType = (String) body.getOrDefault("changeType", "adjustment");
        String reason = (String) body.getOrDefault("reason", "");
        Integer referenceId = body.get("referenceId") instanceof Number ? ((Number)body.get("referenceId")).intValue() : null;
        String referenceType = (String) body.getOrDefault("referenceType", null);

        if (qtyChange == null) return ResponseEntity.badRequest().body(Map.of("ok", false, "msg", "qtyChange required"));

        int rows = dao.updateStockAndLog(id, qtyChange, changeType, adminId, reason, referenceId, referenceType);
        if (rows > 0) return ResponseEntity.ok(Map.of("ok", true));
        return ResponseEntity.badRequest().body(Map.of("ok", false, "msg", "Could not update stock (product missing or would go negative)"));
    }
}

