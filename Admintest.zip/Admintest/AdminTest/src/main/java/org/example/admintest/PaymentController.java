package org.example.admintest;

import jakarta.servlet.http.HttpSession;
import org.example.admintest.payment.PaymentResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@Controller
@RequestMapping("/admin/payments")
public class PaymentController {

    private final PaymentFunctions dao;

    public PaymentController(PaymentFunctions dao) {
        this.dao = dao;
    }

    @GetMapping
    public String paymentsPage(HttpSession session) {
        if (!Boolean.TRUE.equals(session.getAttribute("isAdminLoggedIn"))) {
            return "redirect:/admin";
        }
        return "adminpayments";
    }


    @GetMapping("/pending")
    @ResponseBody
    public List<Payment> pending(HttpSession session) {
        if (!Boolean.TRUE.equals(session.getAttribute("isAdminLoggedIn"))) {
            // return empty list or throw 401; here empty list so UI can handle
            return List.of();
        }
        return dao.findByStatus("pending");
    }

    @GetMapping("/{id}")
    @ResponseBody
    public ResponseEntity<?> get(@PathVariable int id, HttpSession session) {
        if (!Boolean.TRUE.equals(session.getAttribute("isAdminLoggedIn"))) {
            return ResponseEntity.status(401).body(Map.of("ok", false, "msg", "Not authorized"));
        }
        try {
            Optional<Payment> p = dao.findById(id);
            return ResponseEntity.ok(p);
        } catch (Exception ex) {
            return ResponseEntity.status(404).body(Map.of("ok", false, "msg", "Payment not found"));
        }
    }

    @PostMapping("/{id}/approve")
    @ResponseBody
    public ResponseEntity<?> approve(@PathVariable int id, HttpSession session) {
        if (!Boolean.TRUE.equals(session.getAttribute("isAdminLoggedIn"))) {
            return ResponseEntity.status(401).body(Map.of("ok", false, "msg", "Not authorized"));
        }
        Object adminObj = session.getAttribute("adminUserId");
        int adminId = 0;
        if (adminObj instanceof Number) adminId = ((Number) adminObj).intValue();

        int rows = dao.approve(id, adminId);
        if (rows > 0) return ResponseEntity.ok(Map.of("ok", true));
        return ResponseEntity.badRequest().body(Map.of("ok", false, "msg", "Could not approve (maybe status not pending)"));
    }

    @PostMapping("/{id}/reject")
    @ResponseBody
    public ResponseEntity<?> reject(@PathVariable int id, @RequestBody Map<String,String> body, HttpSession session) {
        if (!Boolean.TRUE.equals(session.getAttribute("isAdminLoggedIn"))) {
            return ResponseEntity.status(401).body(Map.of("ok", false, "msg", "Not authorized"));
        }
        Object adminObj = session.getAttribute("adminUserId");
        int adminId = 0;
        if (adminObj instanceof Number) adminId = ((Number) adminObj).intValue();

        String reason = body.getOrDefault("reason","Rejected by admin");
        int rows = dao.reject(id, adminId, reason);
        if (rows > 0) return ResponseEntity.ok(Map.of("ok", true));
        return ResponseEntity.badRequest().body(Map.of("ok", false, "msg", "Could not reject"));
    }

    @PostMapping("/{id}/refund")
    @ResponseBody
    public ResponseEntity<?> refund(@PathVariable int id, @RequestBody Map<String,String> body, HttpSession session) {
        if (!Boolean.TRUE.equals(session.getAttribute("isAdminLoggedIn"))) {
            return ResponseEntity.status(401).body(Map.of("ok", false, "msg", "Not authorized"));
        }
        Object adminObj = session.getAttribute("adminUserId");
        int adminId = 0;
        if (adminObj instanceof Number) adminId = ((Number) adminObj).intValue();

        String reason = body.getOrDefault("reason","Refund processed");
        int rows = dao.refund(id, adminId, reason);
        if (rows > 0) return ResponseEntity.ok(Map.of("ok", true));
        return ResponseEntity.badRequest().body(Map.of("ok", false, "msg", "Could not refund (status must be completed or processing)"));
    }


    @Autowired
    private org.example.admintest.payment.PaymentProcessor paymentProcessor;

    @PostMapping("/{id}/process")
    @ResponseBody
    public ResponseEntity<?> process(@PathVariable int id, HttpSession session) {
        if (!Boolean.TRUE.equals(session.getAttribute("isAdminLoggedIn"))) {
            return ResponseEntity.status(401).body(Map.of("ok", false, "msg", "Not authorized"));
        }
        PaymentResult result = paymentProcessor.processPaymentById(id);
        if (result.isSuccess()) {
            return ResponseEntity.ok(Map.of("ok", true, "msg", result.getMessage()));
        } else {
            return ResponseEntity.badRequest().body(Map.of("ok", false, "msg", result.getMessage()));
        }
    }

}
