package org.example.admintest;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class GenBcrypt {
    public static void main(String[] args) {
        BCryptPasswordEncoder enc = new BCryptPasswordEncoder(10);
        String hash = enc.encode("admin123"); // change password as needed
        System.out.println(hash);
    }
}

