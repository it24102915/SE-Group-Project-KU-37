package org.example.admintest;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

@Repository
public class PaymentFunctions {
    private final JdbcTemplate jdbc;

    public PaymentFunctions(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    private final RowMapper<Payment> mapper = new RowMapper<>() {
        @Override
        public Payment mapRow(ResultSet rs, int rowNum) throws SQLException {
            Payment p = new Payment();
            p.setPaymentId(rs.getInt("PaymentID"));
            p.setOrderId(rs.getInt("OrderID"));
            p.setPaymentMethod(rs.getString("PaymentMethod"));
            p.setAmount(rs.getDouble("Amount"));
            p.setStatus(rs.getString("Status"));
            java.sql.Timestamp ts = rs.getTimestamp("PaymentDate");
            if (ts != null) p.setPaymentDate(ts.toLocalDateTime());
            int vb = rs.getInt("VerifiedBy"); if (!rs.wasNull()) p.setVerifiedBy(vb);
            java.sql.Timestamp vt = rs.getTimestamp("VerifiedAt"); if (vt != null) p.setVerifiedAt(vt.toLocalDateTime());
            int rb = rs.getInt("RefundedBy"); if (!rs.wasNull()) p.setRefundedBy(rb);
            java.sql.Timestamp rt = rs.getTimestamp("RefundedAt"); if (rt != null) p.setRefundedAt(rt.toLocalDateTime());
            p.setRefundReason(rs.getString("RefundReason"));
            return p;
        }
    };

    public List<Payment> findByStatus(String status) {
        String sql = "SELECT PaymentID, OrderID, PaymentMethod, Amount, Status, PaymentDate, VerifiedBy, VerifiedAt, RefundedBy, RefundedAt, RefundReason FROM Payments WHERE Status = ? ORDER BY PaymentDate DESC";
        return jdbc.query(sql, mapper, status);
    }


    public int approve(int paymentId, int adminUserId) {
        String sql = "UPDATE Payments SET Status = 'completed', VerifiedBy = ?, VerifiedAt = GETDATE() WHERE PaymentID = ? AND Status = 'pending'";
        return jdbc.update(sql, adminUserId, paymentId);
    }

    public int reject(int paymentId, int adminUserId, String reason) {
        String sql = "UPDATE Payments SET Status = 'failed', VerifiedBy = ?, VerifiedAt = GETDATE(), GatewayResponse = ? WHERE PaymentID = ? AND Status = 'pending'";
        return jdbc.update(sql, adminUserId, reason, paymentId);
    }

    public int refund(int paymentId, int adminUserId, String reason) {
        String sql = "UPDATE Payments SET Status = 'refunded', RefundedBy = ?, RefundedAt = GETDATE(), RefundReason = ? WHERE PaymentID = ? AND Status IN ('completed','processing')";
        return jdbc.update(sql, adminUserId, reason, paymentId);
    }

    public Optional<Payment> findById(int paymentId) {
        String sql = "SELECT PaymentID, OrderID, PaymentMethod, Amount, TransactionID, PaymentDate, Status, PaymentDetails, GatewayResponse, VerifiedBy, VerifiedAt, RefundedBy, RefundedAt, RefundReason FROM Payments WHERE PaymentID = ?";
        List<Payment> list = jdbc.query(sql, new Object[]{paymentId}, new RowMapper<Payment>() {
            @Override
            public Payment mapRow(ResultSet rs, int rowNum) throws SQLException {
                Payment p = new Payment();
                p.setPaymentId(rs.getInt("PaymentID"));
                p.setOrderId(rs.getInt("OrderID"));
                p.setPaymentMethod(rs.getString("PaymentMethod"));
                p.setAmount(rs.getDouble("Amount"));
                p.setTransactionID(rs.getString("TransactionID"));
                // NOTE: your Payment.java uses LocalDateTime for paymentDate — convert if necessary
                java.sql.Timestamp ts = rs.getTimestamp("PaymentDate");
                if (ts != null) p.setPaymentDate(ts.toLocalDateTime());
                p.setStatus(rs.getString("Status"));
                p.setPaymentDetails(rs.getString("PaymentDetails"));
                p.setGatewayResponse(rs.getString("GatewayResponse"));
                // verified/refunded fields set only if you need them
                return p;
            }
        });
        if (list.isEmpty()) return Optional.empty();
        return Optional.of(list.get(0));
    }

    // 2) updateStatus
    public int updateStatus(int paymentId, String status) {
        String sql = "UPDATE Payments SET Status = ?, PaymentDate = GETDATE() WHERE PaymentID = ?";
        return jdbc.update(sql, status, paymentId);
    }

    // 3) updateAfterProcessing — set status, gatewayResponse, TransactionID, PaymentDetails
    public int updateAfterProcessing(int paymentId, String status, String gatewayResponse, String transactionId, String paymentDetails) {
        String sql = "UPDATE Payments SET Status = ?, GatewayResponse = ?, TransactionID = ?, PaymentDetails = ?, PaymentDate = GETDATE() WHERE PaymentID = ?";
        return jdbc.update(sql, status, gatewayResponse, transactionId, paymentDetails, paymentId);
    }

    // 4) optional: insert log
    public int insertPaymentLog(int paymentId, String attemptStatus, String gatewayResponse, String transactionId, String notes) {
        // If you add PaymentLogs table, insert here. Otherwise, you can skip.
        return 0;
    }
}
