package org.example.admintest.payment;

import org.springframework.stereotype.Service;
import java.util.Map;

@Service
public class PaymentStrategyFactory {
    private final  Map<String, PaymentStrategy> strategyMap;

    public PaymentStrategyFactory(Map<String, PaymentStrategy> strategyMap) {
        this.strategyMap = strategyMap;
    }

    public PaymentStrategy getStrategy(String method) {
        if (method == null) method = "";
        method = method.toLowerCase();
        PaymentStrategy s = strategyMap.get(method);
        if (s != null) return s;
        if (strategyMap.containsKey("credit_card")) return strategyMap.get("credit_card");
        String finalMethod = method;
        return payment -> PaymentResult.failure("Payment method not supported: " + finalMethod, null);
    }
}

