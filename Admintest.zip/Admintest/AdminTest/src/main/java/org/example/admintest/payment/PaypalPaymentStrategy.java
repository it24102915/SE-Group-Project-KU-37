package org.example.admintest.payment;

import org.example.admintest.Payment;
import org.springframework.stereotype.Component;

@Component("paypal")
public class PaypalPaymentStrategy implements PaymentStrategy {
    @Override
    public PaymentResult process(Payment payment) {
        String txn = "PAYPAL-" + System.currentTimeMillis();
        String gw = "Simulated PayPal response: txn=" + txn;
        return PaymentResult.success("PayPal processed", gw, txn);
    }
}

