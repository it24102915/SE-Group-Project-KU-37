package org.example.admintest.payment;

import org.example.admintest.Payment;
import org.springframework.stereotype.Component;

@Component("cash_on_delivery")
public class CashOnDeliveryStrategy implements PaymentStrategy {
    @Override
    public PaymentResult process(Payment payment) {
        return PaymentResult.success("Cash on delivery — collect on delivery", null, null);
    }
}
