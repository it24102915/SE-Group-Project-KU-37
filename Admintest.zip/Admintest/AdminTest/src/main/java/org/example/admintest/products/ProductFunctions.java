package org.example.admintest.products;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class ProductFunctions {
    private final JdbcTemplate jdbc;

    public ProductFunctions(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    private final RowMapper<Product> mapper = new RowMapper<>() {
        @Override
        public Product mapRow(ResultSet rs, int rowNum) throws SQLException {
            Product p = new Product();
            p.setProductId(rs.getInt("ProductID"));
            p.setProductName(rs.getString("ProductName"));
            p.setDescription(rs.getString("Description"));
            p.setPrice(rs.getBigDecimal("Price"));
            p.setStockQuantity(rs.getInt("StockQuantity"));
            int bid = rs.getInt("BrandID"); if (!rs.wasNull()) p.setBrandId(bid);
            p.setWeight(rs.getBigDecimal("Weight"));
            p.setStatus(rs.getString("Status"));
            p.setCreatedBy(rs.getInt("CreatedBy"));
            int ab = rs.getInt("ApprovedBy"); if (!rs.wasNull()) p.setApprovedBy(ab);
            p.setRating(rs.getBigDecimal("Rating"));
            return p;
        }
    };

    public List<Product> findByStatus(String status) {
        String sql = "SELECT ProductID, ProductName, Description, Price, StockQuantity, BrandID, Weight, Status, CreatedBy, ApprovedBy, Rating FROM Products WHERE Status = ? ORDER BY ProductName";
        return jdbc.query(sql, mapper, status);
    }

    public int countByStatus(String status) {
        String sql = "SELECT COUNT(*) FROM Products WHERE Status = ?";
        return jdbc.queryForObject(sql, Integer.class, status);
    }

    public Product findById(int productId) {
        String sql = "SELECT ProductID, ProductName, Description, Price, StockQuantity, BrandID, Weight, Status, CreatedBy, ApprovedBy, Rating FROM Products WHERE ProductID = ?";
        List<Product> list = jdbc.query(sql, mapper, productId);
        return list.isEmpty() ? null : list.get(0);
    }

    public int approve(int productId, int adminUserId) {
        String sql = "UPDATE Products SET Status = 'approved', ApprovedBy = ? WHERE ProductID = ? AND Status = 'pending'";
        return jdbc.update(sql, adminUserId, productId);
    }

    public int reject(int productId, int adminUserId, String reason) {
        if (reason == null) reason = "";
        String sql = "UPDATE Products SET Status = 'rejected', ApprovedBy = ?, " +
                "Description = CASE WHEN COALESCE(Description,'') = '' THEN ? " +
                "ELSE CONCAT(Description, ' [Rejected: ', ?, ']') END " +
                "WHERE ProductID = ? AND Status = 'pending'";
        return jdbc.update(sql, adminUserId, reason, reason, productId);
    }

    public List<Product> findDiscontinued() {
        return findByStatus("discontinued");
    }

    public int countDiscontinued() {
        return countByStatus("discontinued");
    }

    @Transactional
    public int updateStockAndLog(int productId, int qtyChange, String changeType, int userId, String reason, Integer referenceId, String referenceType) {
        Integer current;
        try {
            current = jdbc.queryForObject("SELECT StockQuantity FROM Products WHERE ProductID = ?", Integer.class, productId);
        } catch (Exception ex) {
            return 0;
        }
        if (current == null) return 0;
        int newQty = current + qtyChange;
        if (newQty < 0) return 0;

        int rows = jdbc.update("UPDATE Products SET StockQuantity = ? WHERE ProductID = ?", newQty, productId);
        if (rows == 0) return 0;

        // Note: GETDATE() is SQL Server. If you use MySQL, replace GETDATE() with CURRENT_TIMESTAMP or NOW().
        String insert = "INSERT INTO InventoryLog (ProductID, ChangeType, QuantityChange, NewStockQuantity, Reason, ReferenceID, ReferenceType, CreatedBy, CreatedAt) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, GETDATE())";
        jdbc.update(insert, productId, changeType, qtyChange, newQty, reason, referenceId, referenceType, userId);

        return 1;
    }
}
