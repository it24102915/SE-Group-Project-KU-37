package org.example.admintest.payment;

import org.example.admintest.Payment;
import org.example.admintest.PaymentFunctions;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.Optional;

@Service
public class PaymentProcessor {
    private final PaymentStrategyFactory factory;
    private final PaymentFunctions dao;

    public PaymentProcessor(PaymentStrategyFactory factory, PaymentFunctions dao) {
        this.factory = factory;
        this.dao = dao;
    }

    @Transactional
    public PaymentResult processPaymentById(int paymentId) {
        Optional<Payment> op = dao.findById(paymentId);
        if (op.isEmpty()) {
            return PaymentResult.failure("Payment record not found: " + paymentId, null);
        }

        Payment payment = op.get();
        dao.updateStatus(paymentId, "processing");

        // choose strategy based on PaymentMethod
        String method = payment.getPaymentMethod();
        PaymentStrategy strategy = factory.getStrategy(method);

        PaymentResult result = strategy.process(payment);

        // persist the result in Payments table
        String newStatus = result.isSuccess() ? "completed" : "failed";
        dao.updateAfterProcessing(paymentId,
                newStatus,
                result.getGatewayResponse(),
                result.getTransactionId(),
                result.getMessage()
        );

        return result;
    }
}

