package org.example.admintest.payment;

import org.example.admintest.Payment;

public interface PaymentStrategy {

    PaymentResult process(Payment payment);
}
