package org.example.admintest.dashboard;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AdminDashboardController {

    @GetMapping("/adminDashBord")
    public String dashboard(HttpSession session, Model model) {
        Boolean loggedIn = (Boolean) session.getAttribute("isAdminLoggedIn");
        if (loggedIn != null && loggedIn) {
            model.addAttribute("adminEmail", session.getAttribute("adminEmail"));
            return "adminDashboard";
        } else {
            // Not logged in: redirect to login
            return "redirect:/admin";
        }
    }

    @GetMapping("/adminLogout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/admin";
    }
}
