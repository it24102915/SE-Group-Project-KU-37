package org.example.admintest.payment;

import org.example.admintest.Payment;
import org.springframework.stereotype.Component;

@Component("bank_transfer")
public class BankTransferPaymentStrategy implements PaymentStrategy {
    @Override
    public PaymentResult process(Payment payment) {
        String txn = "BANK-" + System.currentTimeMillis();
        String gw = "Bank transfer simulated: reference=" + txn;
        return PaymentResult.success("Bank transfer pending confirmation", gw, txn);
    }
}

