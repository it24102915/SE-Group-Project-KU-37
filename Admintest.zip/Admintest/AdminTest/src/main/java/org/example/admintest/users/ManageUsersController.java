package org.example.admintest.users;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/admin/users")
public class ManageUsersController {

    @Autowired
    private ManageUsers userService;

    @GetMapping
    public String listUsers(HttpSession session, Model model,
                            @RequestParam(name = "page", defaultValue = "0") int page,
                            @RequestParam(name = "size", defaultValue = "25") int size) {

        if (!Boolean.TRUE.equals(session.getAttribute("isAdminLoggedIn"))) {
            return "redirect:/admin";
        }

        model.addAttribute("rows", userService.listUsers(page, size));
        model.addAttribute("page", page);
        model.addAttribute("size", size);
        model.addAttribute("totalUsers", userService.getTotalUsers());
        model.addAttribute("pendingCount", userService.countPendingUsers());
        return "adminUsers";
    }

    @PostMapping("/{id}/approve")
    public String approveUser(@PathVariable("id") Long userId, HttpSession session, RedirectAttributes ra) {
        if (!Boolean.TRUE.equals(session.getAttribute("isAdminLoggedIn"))) {
            return "redirect:/admin";
        }

        try {
            Long adminId = null;
            Object adminObj = session.getAttribute("adminUserId");
            if (adminObj instanceof Number) adminId = ((Number) adminObj).longValue();

            System.out.println("Attempting to approve user ID: " + userId + " by admin: " + adminId);

            boolean ok = userService.approveUser(userId, adminId == null ? 0L : adminId);

            System.out.println("Approval result: " + ok);

            if (ok) {
                ra.addFlashAttribute("msg", "User approved successfully.");
            } else {
                ra.addFlashAttribute("err", "User not found, already approved, or not in pending status.");
            }
        } catch (Exception e) {
            System.out.println("Error in approveUser: " + e.getMessage());
            e.printStackTrace();
            ra.addFlashAttribute("err", "An error occurred while approving the user.");
        }

        return "redirect:/admin/users";
    }

    @PostMapping("/{id}/suspend")
    public String suspendUser(@PathVariable("id") Long userId, HttpSession session, RedirectAttributes ra) {
        if (!Boolean.TRUE.equals(session.getAttribute("isAdminLoggedIn"))) {
            return "redirect:/admin";
        }
        boolean ok = userService.suspendUser(userId);
        if (ok) ra.addFlashAttribute("msg", "User suspended."); else ra.addFlashAttribute("err", "User not found or could not be suspended.");
        return "redirect:/admin/users";
    }

    @PostMapping("/{id}/delete")
    public String deleteUser(@PathVariable("id") Long userId, HttpSession session, RedirectAttributes ra) {
        if (!Boolean.TRUE.equals(session.getAttribute("isAdminLoggedIn"))) {
            return "redirect:/admin";
        }
        int result = userService.deleteUserIfSafe(userId);
        if (result == 1) ra.addFlashAttribute("msg", "User deleted.");
        else if (result == -1) ra.addFlashAttribute("err", "User linked to ongoing orders/deliveries - cannot delete.");
        else ra.addFlashAttribute("err", "User not found or could not be deleted.");
        return "redirect:/admin/users";
    }
}
