package org.example.admintest.dashboard;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Map;

@Controller
public class AdminLogin {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @GetMapping("/index")
    public String index() {
        return "index";
    }

    @PostMapping("/loginForAdmin")
    public String getID(@RequestParam("email") String email,
                        @RequestParam("password") String password,
                        HttpSession session) {

        try {
            // Select using aliases so we know the Map keys (lowercase)
            String sql = "SELECT UserID, Username AS username, Email AS email, PasswordHash AS password_hash, " +
                    "Role AS role, Status AS status " +
                    "FROM Users WHERE Email = ?";

            Map<String, Object> user = jdbcTemplate.queryForMap(sql, email);

            String storedHash = (String) user.get("password_hash"); // alias ensures this key exists
            Object statusObj = user.get("status");
            String roleStr = user.get("role") == null ? null : user.get("role").toString();
            String username = user.get("username") == null ? null : user.get("username").toString();

            boolean isApproved = false;
            if (statusObj != null) {
                if (statusObj instanceof Boolean) {
                    isApproved = (Boolean) statusObj;
                } else if (statusObj instanceof Number) {
                    isApproved = ((Number) statusObj).intValue() != 0;
                } else {
                    String s = statusObj.toString().trim().toLowerCase();
                    isApproved = s.equals("approved") || s.equals("active") || s.equals("true") || s.equals("1");
                }
            }

            if (!isApproved) {
                session.setAttribute("loginError", "Account is not active/approved.");
                return "admin";
            }

            if (storedHash == null || storedHash.isEmpty()) {
                session.setAttribute("loginError", "Account has no password set. Contact admin.");
                return "admin";
            }

            // Verify password using BCrypt
            if (passwordEncoder.matches(password, storedHash)) {
                session.setAttribute("isAdminLoggedIn", true);
                // store useful info in session
                session.setAttribute("adminUsername", username);
                session.setAttribute("adminEmail", email);
                session.setAttribute("adminRole", roleStr);

                Integer userId = (Integer) user.get("UserID");
                if (userId != null) {
                    session.setAttribute("adminUserId", userId);
                }
                session.removeAttribute("loginError");
                return "redirect:/adminDashBord";
            } else {
                session.setAttribute("loginError", "Invalid email or password.");
                return "admin";
            }

        } catch (EmptyResultDataAccessException ex) {
            // no user found
            session.setAttribute("loginError", "Invalid email or password.");
            return "admin";
        } catch (Exception ex) {
            ex.printStackTrace(); // replace with logger in production
            session.setAttribute("loginError", "Server error. Try again later.");
            return "admin";
        }
    }

    @GetMapping("/admin")
    public String adminLogin() {
        return "admin";
    }
}
