package org.example.admintest.users;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;
import java.util.Map;

@Service
public class ManageUsers {

    @Autowired
    private JdbcTemplate jdbc;

    public int getTotalUsers() {
        Integer count = jdbc.queryForObject("SELECT COUNT(*) FROM Users", Integer.class);
        return count == null ? 0 : count;
    }

    public List<Map<String, Object>> listUsers(int page, int size) {
        if (page < 0) page = 0;
        if (size <= 0 || size > 500) size = 25;
        int offset = page * size;
        String sql = "SELECT UserID, Username, Email, FirstName, LastName, Phone, Role, " +
                "CASE Status " +
                "  WHEN 'active' THEN 'Approved' " +
                "  WHEN 'pending' THEN 'Pending' " +
                "  WHEN 'suspended' THEN 'Suspended' " +
                "  WHEN 'rejected' THEN 'Rejected' " +
                "  ELSE Status " +
                "END AS Status, " +
                "LastLogin, DateOfBirth " +
                "FROM Users ORDER BY UserID DESC OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";
        return jdbc.queryForList(sql, offset, size);
    }

    public Map<String, Object> getUserById(long userId) {
        String sql = "SELECT UserID, Username, Email, FirstName, LastName, Phone, Role, " +
                "CASE Status " +
                "  WHEN 'active' THEN 'Approved' " +
                "  WHEN 'pending' THEN 'Pending' " +
                "  WHEN 'suspended' THEN 'Suspended' " +
                "  WHEN 'rejected' THEN 'Rejected' " +
                "  ELSE Status " +
                "END AS Status, " +
                "LastLogin, DateOfBirth " +
                "FROM Users WHERE UserID = ?";
        return jdbc.queryForMap(sql, userId);
    }

    @Transactional
    public boolean approveUser(long userId, long adminUserId) {
        String sql = "UPDATE Users SET Status = 'active', ApprovedBy = ?, ApprovedAt = ? WHERE UserID = ? AND Status = 'Pending'";
        int rows = jdbc.update(sql, adminUserId, Timestamp.from(Instant.now()), userId);
        return rows > 0;
    }

    @Transactional
    public int deleteUserIfSafe(long userId) {
        Integer exists = jdbc.queryForObject("SELECT COUNT(*) FROM Users WHERE UserID = ?", Integer.class, userId);
        if (exists == null || exists == 0) return 0;
        Integer linked = 0;
        try {
            linked = jdbc.queryForObject(
                    "SELECT COUNT(*) FROM Orders WHERE CustomerID = ? AND OrderStatus IN ('pending_payment','processing','shipped')",
                    Integer.class, userId);
        } catch (Exception ex) {
            linked = 0;
        }
        if (linked != null && linked > 0) return -1;
        int deleted = jdbc.update("DELETE FROM Users WHERE UserID = ?", userId);
        return deleted > 0 ? 1 : 0;
    }

    @Transactional
    public boolean suspendUser(long userId) {
        int rows = jdbc.update("UPDATE Users SET Status = 'suspended' WHERE UserID = ?", userId);
        return rows > 0;
    }

    public int countPendingUsers() {
        Integer c = jdbc.queryForObject("SELECT COUNT(*) FROM Users WHERE Status = 'pending'", Integer.class);
        return c == null ? 0 : c;
    }
}

