package org.example.admintest.payment;

public class PaymentResult {
    private final boolean success;
    private final String message;
    private final String gatewayResponse;
    private final String transactionId;

    public PaymentResult(boolean success, String message, String gatewayResponse, String transactionId) {
        this.success = success;
        this.message = message;
        this.gatewayResponse = gatewayResponse;
        this.transactionId = transactionId;
    }

    public boolean isSuccess() {
        return success;
    }

    public String getMessage() {
        return message;
    }

    public String getGatewayResponse() {
        return gatewayResponse;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public static PaymentResult success(String message, String gatewayResponse, String transactionId) {
        return new PaymentResult(true, message, gatewayResponse, transactionId);
    }

    public static PaymentResult failure(String message, String gatewayResponse) {
        return new PaymentResult(false, message, gatewayResponse, null);
    }
}